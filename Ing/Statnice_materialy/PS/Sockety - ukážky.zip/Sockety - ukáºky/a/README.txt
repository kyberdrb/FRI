Aplikacia sluzi na (asynchronnu) vymenu textovych sprav medzi dvomi pouzivatelmi.
Asynchronnost je zabezpecena vyuzitim funkcie select.

Preklad servera:
	gcc k_a_definitions.c k_a_server.c -o k_a_server
Preklad klienta:
	gcc k_a_definitions.c k_a_client.c -o k_a_client

Spustenie servera:
	./k_s_server 10000 server
Spustenie klienta:
	./k_s_client localhost 10000 klient
	
Ukoncenie aplikacie:
	klient alebo server zada spravu ":end"
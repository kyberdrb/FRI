#include "k_a_definitions.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include <unistd.h>
#include <fcntl.h>

char *endMsg = ":end";

void data_init(DATA *data, const char* userName, const int socket) {
	data->socket = socket;
	data->userName[USER_LENGTH] = '\0';
	strncpy(data->userName, userName, USER_LENGTH);
}

void data_readWrite(const DATA *data) {
	char buffer[BUFFER_LENGTH + 1];
	buffer[BUFFER_LENGTH] = '\0';
	int userNameLength = strlen(data->userName);

	fd_set sockets;
    FD_ZERO(&sockets);
    int max = (data->socket > STDIN_FILENO ? data->socket : STDIN_FILENO) + 1;

	//pre pripad, ze chceme poslat viac dat, ako je kapacita buffra
	fcntl(STDIN_FILENO, F_SETFL, fcntl(STDIN_FILENO, F_GETFL, 0) | O_NONBLOCK);
	int end = 0;
    while(!end) {
		FD_SET(data->socket, &sockets);
		FD_SET(STDIN_FILENO, &sockets);
		select(max, &sockets, NULL, NULL, NULL);
        if (FD_ISSET(data->socket, &sockets)) {
			read(data->socket, buffer, BUFFER_LENGTH);
			
			char *posSemi = strchr(buffer, ':');
			char *pos = strstr(posSemi + 1, endMsg);
			if (pos != NULL && pos - posSemi == 2 && *(pos + strlen(endMsg)) == '\0') {
				*(pos - 2) = '\0';
				printf("Pouzivatel %s ukoncil komunikaciu.\n", buffer);
				end = 1;
			} else {
				printf("%s\n", buffer);
			}			
        }
		if (FD_ISSET(STDIN_FILENO, &sockets)) {
			sprintf(buffer, "%s: ", data->userName);
			char *textStart = buffer + (userNameLength + 2);
			while (fgets(textStart, BUFFER_LENGTH - (userNameLength + 2), stdin) > 0) {
				char *pos = strchr(textStart, '\n');
				if (pos != NULL) {
					*pos = '\0';
				}
				write(data->socket, buffer, strlen(buffer) + 1);
				
				if (strstr(textStart, endMsg) == textStart && strlen(textStart) == strlen(endMsg)) {
					printf("Koniec komunikacie.\n");
					end = 1;
				}
			}
        }
    }
	fcntl(STDIN_FILENO, F_SETFL, fcntl(STDIN_FILENO, F_GETFL, 0) & ~O_NONBLOCK);
}

void printError(char *str) {
    if (errno != 0) {
		perror(str);
	}
	else {
		fprintf(stderr, "%s\n", str);
	}
    exit(EXIT_FAILURE);
}


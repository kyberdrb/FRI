#ifndef K_DEFINITIONS_H
#define	K_DEFINITIONS_H

#ifdef	__cplusplus
extern "C" {
#endif

#define BUFFER_LENGTH 300
extern char *endMsg;

void printError(char *str);

#ifdef	__cplusplus
}
#endif

#endif	/* K_DEFINITIONS_H */

